def merge_and_model(cell, chrname):
    import os
    from pytadbit import Chromosome
    from pytadbit.parsers.hic_parser import load_hic_data_from_bam
    from pytadbit.mapping import merge_bams
    import glob
    import re
    import pickle
    import subprocess

    bam_path = '{}.bam'.format(cell)
    bai_path = '{}.bam.bai'.format(cell)
    subprocess.call('aws s3 cp s3://crispr-il-wg1/datasets/tuller_lab/raw/hic/{1}/{0} ./{0}'.format(bam_path, cell), shell=True)
    subprocess.call('aws s3 cp s3://crispr-il-wg1/datasets/tuller_lab/raw/hic/{1}/{0} ./{0}'.format(bai_path, cell), shell=True)

    if not ((os.path.exists(bam_path)) and (os.path.exists(bai_path))):
        subprocess.call('aws s3 cp s3://crispr-il-wg1/datasets/tuller_lab/raw/hic/{}/ ./ --recursive --exclude "*" --include "*.bam"'.format(cell),
                        shell=True)
        SRRs = glob.glob('SRR*.bam')
        for i in range(len(SRRs)):
            SRRs[i] = (re.search('SRR\d*\.bam', SRRs[i]).group())
        if len(SRRs) > 1:
            merge_bams(SRRs[0], SRRs[1], bam_path)
            if len(SRRs) > 2:
                for i in range(2, len(SRRs)):
                    os.rename(bam_path, 'temp.bam')
                    merge_bams('temp.bam', SRRs[i], bam_path)
                    os.remove('temp.bam')
        else:
            os.rename(SRRs[0], bam_path)
        subprocess.call("aws s3 cp {0} s3://crispr-il-wg1/datasets/tuller_lab/raw/hic/{1}/{0}".format(bam_path, cell), shell=True)
        subprocess.call("aws s3 cp {0} s3://crispr-il-wg1/datasets/tuller_lab/raw/hic/{1}/{0}".format(bai_path, cell), shell=True)
        for filename in SRRs:
            os.remove(filename)

    reso = 100000
    bias_path = '{}_res{}.biases'.format(cell, reso)
    subprocess.call("aws s3 cp s3://crispr-il-wg1/datasets/tuller_lab/raw/hic/{1}/{0} ./{0}".format(bias_path, cell), shell=True)
    if not os.path.exists(bias_path):
        hic_data = load_hic_data_from_bam(bam_path, reso, ncpus=8)
        hic_data.filter_columns(draw_hist=False, min_count=2500, by_mean=True, silent=True)
        hic_data.normalize_hic(iterations=100, max_dev=0.00001)
        hic_data.save_biases(bias_path)
        subprocess.call("aws s3 cp {0} s3://crispr-il-wg1/datasets/tuller_lab/raw/hic/{1}/{0}".format(bias_path, cell), shell=True)

    hic_data = load_hic_data_from_bam(bam_path, resolution=reso, region=chrname, biases=bias_path, ncpus=8)
    crm = Chromosome(chrname)
    crm.add_experiment(cell, hic_data=[hic_data.get_matrix(focus=chrname)],
                       norm_data=[hic_data.get_matrix(focus=chrname, normalized=True)],
                       resolution=reso)
    crm.find_tad([cell], n_cpus=8)
    chr_tdb = '{}_res{}.tdb'.format(chrname, reso)
    crm.save_chromosome(chr_tdb)
    subprocess.call("aws s3 cp {0} s3://crispr-il-wg1/datasets/tuller_lab/raw/hic/{1}/{0}".format(chr_tdb, cell), shell=True)
    exp = crm.experiments[0]
    exp.load_hic_data([hic_data.get_matrix(focus=chrname)])
    exp.load_norm_data([hic_data.get_matrix(focus=chrname, normalized=True)])

    hic_mat = exp.get_hic_matrix()
    num_particles = len(hic_mat)
    part_capacity = int(800)
    if num_particles > 1000:
        starts = range(0, int(num_particles) / (part_capacity / 2))
        starts = [i * part_capacity / 2 + 1 for i in starts]
        ends = [min(num_particles, i + part_capacity-1) for i in starts]
    else:
        starts = [1]
        ends = [num_particles]

    for i in range(len(starts)):
        params_pkl = 'params_{}_res{}_st{}.pkl'.format(chrname, reso, starts[i])
        subprocess.call("aws s3 cp s3://crispr-il-wg1/datasets/tuller_lab/raw/hic/{1}/{0} ./{0}".format(params_pkl, cell), shell=True)
        print(starts[i])
        if not os.path.exists(params_pkl):
            opt_params = exp.optimal_imp_parameters(start=starts[i], end=ends[i], n_models=100, n_keep=20, n_cpus=20, upfreq_range=(0, 0.6, 0.2),
                                                    lowfreq_range=(-0.9, 0, 0.3), maxdist_range=(1000, 2000, 500))
            pickle.dump(opt_params, open(params_pkl, 'wb'))
            subprocess.call("aws s3 cp {0} s3://crispr-il-wg1/datasets/tuller_lab/raw/hic/{1}/{0}".format(params_pkl, cell), shell=True)

    for i in range(len(starts)):
        models_pkl = 'models_{}_res{}_st{}.pkl'.format(chrname, reso, starts[i])
        subprocess.call("aws s3 cp s3://crispr-il-wg1/datasets/tuller_lab/raw/hic/{1}/{0} ./{0}".format(models_pkl, cell), shell=True)
        if not os.path.exists(models_pkl):
            params_pkl = 'params_{}_res{}_st{}.pkl'.format(chrname, reso, starts[i])
            opt_params = pickle.load(open(params_pkl, 'rb'))
            opt_params = opt_params.get_best_parameters_dict()
            models = exp.model_region(start=starts[i], end=ends[i], n_models=400, n_keep=100, n_cpus=8, config=opt_params)
            pickle.dump(models, open(models_pkl, 'wb'))
            subprocess.call("aws s3 cp {0} s3://crispr-il-wg1/datasets/tuller_lab/raw/hic/{1}/{0}".format(models_pkl, cell), shell=True)
