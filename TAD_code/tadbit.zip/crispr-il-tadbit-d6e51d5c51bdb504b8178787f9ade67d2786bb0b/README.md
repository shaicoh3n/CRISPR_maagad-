A Dockerfile to run TADbit (calculating 3D structure of the genome), meant to be run in AWS Batch. Build using:

```docker build . -t tadbit:latest```

The calculation is done in two rounds:
1. Separate calculations for each experiments (i.e. SRRs) - run by ```f2m_script.sh```.
Using the AWS_BATCH_JOB_ARRAY_INDEX variable, the script opens ```srr_jobs.txt``` and gets its job's parameters (each line in the txt file corresponds to a different job). Run using:

```docker run tadbit /bin/bash -c "bash f2m_script.sh"```

2. Merging the per-SRR results to per-cell results - run by ```merge_script.sh```.
Similarly to the previous script, gets parameters from ```cell_jobs.txt``` based on job's index. Run using:

```docker run tadbit /bin/bash -c "bash merge_script.sh"```
