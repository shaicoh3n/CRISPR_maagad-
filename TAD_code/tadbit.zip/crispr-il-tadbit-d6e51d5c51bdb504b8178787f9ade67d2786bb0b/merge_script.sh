source /root/miniconda2/bin/activate tadbit

aws s3 cp s3://crispr-il-wg1/datasets/tuller_lab/raw/hic/cell_jobs.txt cell_jobs.txt

line_num=$((AWS_BATCH_JOB_ARRAY_INDEX + 1))
line=$(sed -n ${line_num}p /home/cell_jobs.txt)
IFS=" " read -r cell chrname <<< "$line"

cp ./merge_and_model.py /aws_batch_root/
cd /aws_batch_root

python -c "from merge_and_model import merge_and_model; merge_and_model('$cell', '$chrname')"