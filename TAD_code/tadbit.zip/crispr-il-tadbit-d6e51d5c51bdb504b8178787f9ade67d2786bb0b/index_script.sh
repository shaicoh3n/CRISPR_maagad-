source /root/miniconda2/bin/activate tadbit

aws s3 cp s3://crispr-il-wg1/datasets/tuller_lab/genomes/genome_jobs.txt /home/genome_jobs.txt

line_num=$((AWS_BATCH_JOB_ARRAY_INDEX + 1))
genome=$(sed -n ${line_num}p /home/genome_jobs.txt)

aws s3 cp s3://crispr-il-wg1/datasets/tuller_lab/genomes/"$genome".fa /aws_batch_root/"$genome".fa

cd /aws_batch_root

gem-indexer -i "$genome".fa -o "$genome"

aws s3 cp /aws_batch_root/"$genome".gem s3://crispr-il-wg1/datasets/tuller_lab/genomes/"$genome".gem