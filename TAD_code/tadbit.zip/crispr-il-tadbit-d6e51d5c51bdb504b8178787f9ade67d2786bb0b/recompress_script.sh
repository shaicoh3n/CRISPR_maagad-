aws s3 cp s3://crispr-il-wg1/datasets/tuller_lab/raw/hic/recompress_jobs.txt recompress_jobs.txt

line_num=$((AWS_BATCH_JOB_ARRAY_INDEX + 1))
line=$(sed -n ${line_num}p /home/recompress_jobs.txt)
IFS=" " read -r cell SRR r <<< "$line"

aws s3 cp s3://crispr-il-wg1/datasets/tuller_lab/raw/hic/"$cell"/"$SRR"_"$r".fastq.dsrc ./"$SRR"_"$r".fastq.dsrc

echo "Deompressing..."
./dsrc d "$SRR"_"$r".fastq.dsrc "$SRR"_"$r".fastq
rm "$SRR"_"$r".fastq.dsrc
echo "gzipping..."
gzip "$SRR"_"$r".fastq

aws s3 cp ./"$SRR"_"$r".fastq.gz s3://crispr-il-wg1/datasets/tuller_lab/raw/hic/"$cell"/"$SRR"_"$r".fastq.gz