if [ $AWS_BATCH_JOB_ARRAY_INDEX -eq 1 ]
then
aws s3 cp s3://crispr-il-wg1/datasets/tuller_lab/raw/hic/iPSC/ /home/ --recursive --exclude "*" --include "arc1.*"
cat arc1.* > SRR9676391_1.fastq.gz
aws s3 cp /home/SRR9676391_1.fastq.gz s3://crispr-il-wg1/datasets/tuller_lab/raw/hic/iPSC/
else
aws s3 cp s3://crispr-il-wg1/datasets/tuller_lab/raw/hic/iPSC/ /home/ --recursive --exclude "*" --include "arc2.*"
cat arc2.* > SRR9676391_2.fastq.gz
aws s3 cp /home/SRR9676391_2.fastq.gz s3://crispr-il-wg1/datasets/tuller_lab/raw/hic/iPSC/
fi