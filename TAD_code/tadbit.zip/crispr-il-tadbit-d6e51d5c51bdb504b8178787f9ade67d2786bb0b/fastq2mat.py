def fastq2mat(SRR,genome,re,cell):
    import os
    import subprocess
    
    os.system('aws s3 cp s3://crispr-il-wg1/datasets/tuller_lab/raw/hic/{1}/{0}.bam ./'.format(SRR,cell))
    if not os.path.exists('{}.bam'.format(SRR)):
        reads = '{}_12.tsv'.format(SRR)
        os.system('aws s3 cp s3://crispr-il-wg1/datasets/tuller_lab/raw/hic/{1}/{0} ./'.format(reads,cell))
        if not os.path.exists(reads):
            from pytadbit.mapping.full_mapper import full_mapping
            os.system('aws s3 cp s3://crispr-il-wg1/datasets/tuller_lab/genomes/{}.fa ./'.format(genome))
            os.system('aws s3 cp s3://crispr-il-wg1/datasets/tuller_lab/genomes/{}.gem ./'.format(genome))
            map_base = SRR + '_{}_full_1-end.map'
            for r in [2, 1]:
                map_name = map_base.format(r)
                os.system('aws s3 cp s3://crispr-il-wg1/datasets/tuller_lab/raw/hic/{1}/{0} ./results/'.format(map_name,cell))
                if not os.path.exists('results/{}'.format(map_name)):
                    fastq_name = '{}_{}.fastq.gz'.format(SRR,r)
                    subprocess.call('aws s3 cp s3://crispr-il-wg1/datasets/tuller_lab/raw/hic/{1}/{0} ./'.format(fastq_name,cell), shell=True)
                    full_mapping(mapper_index_path='{}.gem'.format(genome), 
                        out_map_dir='results/',
                        fastq_path=fastq_name,
                        r_enz=re, frag_map=True, clean=True,
                        temp_dir='tmp/')
                    os.system('aws s3 cp ./results/{0} s3://crispr-il-wg1/datasets/tuller_lab/raw/hic/{1}/{0}'.format(map_name,cell))
                    
            from pytadbit.parsers.genome_parser import parse_fasta
            genome_seq = parse_fasta('{}.fa'.format(genome))
            
            from pytadbit.parsers.map_parser import parse_map
            map_num = 'results/' + map_base
            maps1 = map_num.format('1')
            maps2 = map_num.format('2')
            reads1 = '{}_1.tsv'.format(SRR)
            reads2 = '{}_2.tsv'.format(SRR)

            from pytadbit.mapping import get_intersection
            parse_map(maps1, maps2, reads1, reads2, genome_seq=genome_seq, re_name=re, verbose=True)
            get_intersection(reads1, reads2, reads, verbose=True)
            os.system('aws s3 cp ./{0} s3://crispr-il-wg1/datasets/tuller_lab/raw/hic/{1}/{0}'.format(reads,cell))
        
        from pytadbit.mapping.filter import filter_reads
        masked = filter_reads(reads,max_molecule_length=750, over_represented=0.005, max_frag_size=100000,
            min_frag_size=50, re_proximity=5, min_dist_to_re=1000)
        
        from pytadbit.mapping.filter import apply_filter
        valid_reads = '{}_valid.tsv'.format(SRR)
        apply_filter(reads, valid_reads, masked, filters=[1, 2, 3, 4, 6, 7, 9, 10])
        
        from pytadbit.parsers.hic_bam_parser import bed2D_to_BAMhic
        bam_path = '{}'.format(SRR) 
        bed2D_to_BAMhic(valid_reads, valid=True, ncpus=8, outbam=bam_path, frmt='mid', masked=None)
        os.system('aws s3 cp ./{0}.bam s3://crispr-il-wg1/datasets/tuller_lab/raw/hic/{1}/{0}.bam'.format(SRR,cell))