import pickle

f = open('cell_jobs.txt', 'w')

for genome in ['human', 'tomato']:
    chrs = pickle.load(open('chrs_{}.pkl'.format(genome), 'rb'))
    if genome == 'human':
        cells = ['T_1', 'HEK293', 'K562', 'THP']
    else:
        cells = ['leaf_tomato']

    for cell in cells:
        for chrom in chrs:
            f.write('{} {}\n'.format(cell, chrom))

f.close()
