import glob
import pickle

fls = glob.glob('models*st*.pkl')

for fl in fls:
    curr_model = pickle.load(open(fl, 'rb'))
    spec_model = fl.replace('models', '')
    spec_model = spec_model.replace('.pkl', '') + '.txt'
    curr_model.density_plot(savedata='density_plot'+spec_model, plot=False,steps=(1))
    curr_model.walking_angle(savedata='walking_angle' + spec_model, plot=False, steps=(1))
    curr_model.interactions(savedata='interactions' + spec_model, plot=False, steps=(1))
    # curr_model.accessibility(savedata='accessibility' + spec_model, plot=False)
