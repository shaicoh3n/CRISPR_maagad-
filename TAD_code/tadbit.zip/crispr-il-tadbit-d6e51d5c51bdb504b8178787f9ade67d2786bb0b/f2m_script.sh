source /root/miniconda2/bin/activate tadbit

aws s3 cp s3://crispr-il-wg1/datasets/tuller_lab/raw/hic/srr_jobs.txt /home/srr_jobs.txt

line_num=$((AWS_BATCH_JOB_ARRAY_INDEX + 1))
line=$(sed -n ${line_num}p /home/srr_jobs.txt)
IFS=" " read SRR cell genome re <<< "$line"

cp ./fastq2mat.py /aws_batch_root/
cd /aws_batch_root
mkdir results
mkdir tmp

python -c "from fastq2mat import fastq2mat; fastq2mat('$SRR', '$genome', '$re', '$cell')"